import { useState, FormEvent } from "react";
import { collection, addDoc, Timestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { ScrollReveal } from "@/components/ScrollReveal";
import { Loader2, CheckCircle } from "lucide-react";

const serviceOptions = [
  "Printer Installation",
  "Printer Repair",
  "AMC Maintenance",
  "Network Setup",
  "Cartridge Support",
  "Troubleshooting",
];

const printerOptions = [
  "HP LaserJet Pro M404",
  "Canon PIXMA G3020",
  "Epson EcoTank L3250",
  "Brother DCP-L2640DW",
  "HP OfficeJet Pro 9015",
  "Ricoh SP C261SFNw",
  "Kyocera ECOSYS M2040dn",
  "Samsung Xpress M2070",
  "Other",
];

const countryCodes = [
  { code: "+1", label: "US +1" },
  { code: "+44", label: "UK +44" },
  { code: "+91", label: "IN +91" },
  { code: "+971", label: "AE +971" },
  { code: "+61", label: "AU +61" },
  { code: "+49", label: "DE +49" },
  { code: "+33", label: "FR +33" },
  { code: "+81", label: "JP +81" },
  { code: "+86", label: "CN +86" },
  { code: "+966", label: "SA +966" },
];

const InquiryForm = () => {
  const [form, setForm] = useState({
    name: "", email: "", countryCode: "+91", phone: "", services: [] as string[], printer: "", message: "",
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) e.email = "Valid email is required";
    if (!form.phone.trim() || form.phone.length < 7) e.phone = "Valid phone number is required";
    if (form.services.length === 0) e.services = "Select at least one service";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const toggleService = (s: string) =>
    setForm((f) => ({
      ...f,
      services: f.services.includes(s) ? f.services.filter((x) => x !== s) : [...f.services, s],
    }));

  const openWhatsApp = () => {
    const msg = encodeURIComponent(
      `New Inquiry:\nName: ${form.name}\nPhone: ${form.countryCode} ${form.phone}\nService: ${form.services.join(", ")}\nPrinter: ${form.printer || "N/A"}\nMessage: ${form.message || "N/A"}`
    );
    window.open(`https://wa.me/?text=${msg}`, "_blank");
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      await addDoc(collection(db, "inquiries"), {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: `${form.countryCode} ${form.phone.trim()}`,
        services: form.services,
        printer: form.printer || "",
        message: form.message.trim(),
        timestamp: Timestamp.now(),
      });
      openWhatsApp();
      setSuccess(true);
      setForm({ name: "", email: "", countryCode: "+91", phone: "", services: [], printer: "", message: "" });
      setTimeout(() => setSuccess(false), 5000);
    } catch {
      openWhatsApp();
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full px-4 py-3 rounded-lg border border-border bg-card text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 transition-shadow duration-200";

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="container mx-auto px-4 max-w-2xl">
        <ScrollReveal className="text-center mb-12">
          <span className="text-sm font-semibold tracking-wider uppercase text-accent">Get In Touch</span>
          <h2 className="text-3xl sm:text-4xl font-bold mt-3 tracking-tight text-balance">Book a Service</h2>
          <p className="text-muted-foreground mt-4">Fill out the form and we'll get back to you within the hour.</p>
        </ScrollReveal>

        <ScrollReveal>
          {success ? (
            <div className="text-center py-16 bg-card rounded-2xl border border-border/60">
              <CheckCircle className="w-16 h-16 text-success mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Inquiry Submitted!</h3>
              <p className="text-muted-foreground">We'll contact you shortly. Thank you!</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-card rounded-2xl p-8 shadow-lg shadow-primary/5 border border-border/60 space-y-5">
              <div>
                <label className="block text-sm font-medium mb-1.5">Name *</label>
                <input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your full name" maxLength={100} />
                {errors.name && <p className="text-destructive text-xs mt-1">{errors.name}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">Email *</label>
                <input className={inputClass} type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@company.com" maxLength={255} />
                {errors.email && <p className="text-destructive text-xs mt-1">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">Phone *</label>
                <div className="flex gap-2">
                  <select
                    className="px-3 py-3 rounded-lg border border-border bg-card text-sm w-28 focus:outline-none focus:ring-2 focus:ring-primary/30"
                    value={form.countryCode}
                    onChange={(e) => setForm({ ...form, countryCode: e.target.value })}
                  >
                    {countryCodes.map((c) => (
                      <option key={c.code} value={c.code}>{c.label}</option>
                    ))}
                  </select>
                  <input className={`${inputClass} flex-1`} type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/[^0-9]/g, "") })} placeholder="9876543210" maxLength={15} />
                </div>
                {errors.phone && <p className="text-destructive text-xs mt-1">{errors.phone}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Service Type *</label>
                <div className="flex flex-wrap gap-2">
                  {serviceOptions.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleService(s)}
                      className={`px-3.5 py-2 rounded-lg text-xs font-medium border transition-all duration-200 active:scale-[0.96] ${
                        form.services.includes(s)
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-muted text-muted-foreground border-border hover:border-primary/30"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                {errors.services && <p className="text-destructive text-xs mt-1">{errors.services}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">Printer Model (optional)</label>
                <select className={inputClass} value={form.printer} onChange={(e) => setForm({ ...form, printer: e.target.value })}>
                  <option value="">Select a printer model</option>
                  {printerOptions.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">Message</label>
                <textarea className={`${inputClass} resize-none`} rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Describe your issue..." maxLength={1000} />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-lg bg-accent text-accent-foreground font-semibold text-sm shadow-lg shadow-accent/20 hover:shadow-xl active:scale-[0.97] transition-all duration-200 disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                {loading ? "Submitting..." : "Submit Inquiry"}
              </button>
            </form>
          )}
        </ScrollReveal>
      </div>
    </section>
  );
};

export default InquiryForm;
