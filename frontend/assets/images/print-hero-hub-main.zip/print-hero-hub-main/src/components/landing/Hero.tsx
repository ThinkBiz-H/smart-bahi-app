import heroBanner from "@/assets/hero-banner.jpg";

const Hero = () => (
  <section id="home" className="relative min-h-[92vh] flex items-center overflow-hidden">
    <img
      src={heroBanner}
      alt="Professional printer setup service"
      className="absolute inset-0 w-full h-full object-cover"
    />
    <div className="absolute inset-0 hero-gradient" />
    <div className="relative container mx-auto px-4 py-32">
      <div className="max-w-2xl">
        <span className="inline-block text-sm font-semibold tracking-wider uppercase text-accent mb-4 animate-fade-up">
          Professional Printer Services
        </span>
        <h1
          className="text-4xl sm:text-5xl lg:text-6xl font-bold text-primary-foreground leading-[1.08] tracking-tight text-balance animate-fade-up delay-100"
          style={{ lineHeight: 1.08 }}
        >
          Printer Setup, Repair & Support Services
        </h1>
        <p className="mt-6 text-lg text-primary-foreground/80 max-w-lg animate-fade-up delay-200" style={{ textWrap: "pretty" }}>
          We install, repair & support all types of printers — from home inkjets to enterprise laser systems. Fast, reliable, affordable.
        </p>
        <div className="flex flex-wrap gap-4 mt-10 animate-fade-up delay-300">
          <a
            href="#contact"
            className="inline-flex items-center justify-center px-7 py-3.5 rounded-lg bg-accent text-accent-foreground font-semibold text-sm shadow-lg shadow-accent/25 hover:shadow-xl hover:shadow-accent/30 active:scale-[0.97] transition-all duration-200"
          >
            Book Service
          </a>
          <a
            href="#printers"
            className="inline-flex items-center justify-center px-7 py-3.5 rounded-lg bg-primary-foreground/10 text-primary-foreground font-semibold text-sm border border-primary-foreground/20 backdrop-blur-sm hover:bg-primary-foreground/15 active:scale-[0.97] transition-all duration-200"
          >
            View Printers
          </a>
        </div>
      </div>
    </div>
  </section>
);

export default Hero;
