import { Printer } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const printers = [
  { name: "HP LaserJet Pro M404", type: "Mono Laser" },
  { name: "Canon PIXMA G3020", type: "Inkjet" },
  { name: "Epson EcoTank L3250", type: "Ink Tank" },
  { name: "Brother DCP-L2640DW", type: "Mono Laser" },
  { name: "HP OfficeJet Pro 9015", type: "All-in-One Inkjet" },
  { name: "Ricoh SP C261SFNw", type: "Color Laser" },
  { name: "Kyocera ECOSYS M2040dn", type: "Mono MFP" },
  { name: "Samsung Xpress M2070", type: "Mono Laser" },
];

const colors = [
  "from-primary/8 to-primary/3",
  "from-accent/8 to-accent/3",
  "from-success/8 to-primary/3",
  "from-primary/6 to-accent/3",
  "from-accent/6 to-primary/3",
  "from-primary/8 to-success/3",
  "from-accent/8 to-success/3",
  "from-success/6 to-accent/3",
];

const PrinterShowcase = () => (
  <section id="printers" className="py-24 bg-muted/50">
    <div className="container mx-auto px-4">
      <ScrollReveal className="text-center mb-16">
        <span className="text-sm font-semibold tracking-wider uppercase text-accent">Our Range</span>
        <h2 className="text-3xl sm:text-4xl font-bold mt-3 tracking-tight text-balance">Printer Models We Support</h2>
        <p className="text-muted-foreground mt-4 max-w-lg mx-auto">
          We service and support a wide range of printers from leading brands.
        </p>
      </ScrollReveal>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
        {printers.map((p, i) => (
          <ScrollReveal key={p.name} delay={i * 70}>
            <div className="bg-card rounded-xl border border-border/60 overflow-hidden card-hover group">
              <div className={`h-40 bg-gradient-to-br ${colors[i]} flex items-center justify-center`}>
                <Printer className="w-16 h-16 text-primary/40 group-hover:text-primary/60 transition-colors duration-300" />
              </div>
              <div className="p-4 text-center">
                <h3 className="font-semibold text-sm">{p.name}</h3>
                <p className="text-xs text-muted-foreground mt-1">{p.type}</p>
              </div>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default PrinterShowcase;
