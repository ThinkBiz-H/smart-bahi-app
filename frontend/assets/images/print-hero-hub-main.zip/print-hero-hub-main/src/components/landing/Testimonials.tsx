import { Star } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const reviews = [
  { name: "Ananya Patel", role: "Office Manager", text: "PrinterPro fixed our network printer issue within 2 hours. Extremely professional and reliable service!", rating: 5 },
  { name: "Marcus Lindgren", role: "Small Business Owner", text: "Set up three new printers across our offices. The team was knowledgeable and very affordable. Highly recommend.", rating: 5 },
  { name: "Fatima Al-Rashid", role: "School Administrator", text: "Our annual maintenance contract with PrinterPro saves us so much hassle. They keep all 12 printers running smoothly.", rating: 4 },
  { name: "David Cheng", role: "Freelancer", text: "Quick response time and genuine cartridge supply. They even helped me pick the right printer for my home office.", rating: 5 },
];

const Testimonials = () => (
  <section id="testimonials" className="py-24 bg-muted/50">
    <div className="container mx-auto px-4">
      <ScrollReveal className="text-center mb-16">
        <span className="text-sm font-semibold tracking-wider uppercase text-accent">Testimonials</span>
        <h2 className="text-3xl sm:text-4xl font-bold mt-3 tracking-tight text-balance">What Our Clients Say</h2>
      </ScrollReveal>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {reviews.map((r, i) => (
          <ScrollReveal key={r.name} delay={i * 90}>
            <div className="bg-card rounded-xl p-6 shadow-sm border border-border/60 h-full flex flex-col">
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: 5 }).map((_, si) => (
                  <Star key={si} className={`w-4 h-4 ${si < r.rating ? "text-accent fill-accent" : "text-border"}`} />
                ))}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed flex-1">"{r.text}"</p>
              <div className="mt-5 pt-4 border-t border-border/60">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                    {r.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{r.name}</p>
                    <p className="text-xs text-muted-foreground">{r.role}</p>
                  </div>
                </div>
              </div>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default Testimonials;
