import { Printer, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => (
  <footer className="bg-foreground py-16">
    <div className="container mx-auto px-4">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 text-background/70 text-sm">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
              <Printer className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold text-background">PrinterPro</span>
          </div>
          <p className="leading-relaxed">
            Professional printer setup, repair & support services for homes and businesses.
          </p>
        </div>
        <div>
          <h4 className="text-background font-semibold mb-4">Services</h4>
          <ul className="space-y-2.5">
            <li>Printer Installation</li>
            <li>Printer Repair</li>
            <li>AMC Maintenance</li>
            <li>Network Setup</li>
          </ul>
        </div>
        <div>
          <h4 className="text-background font-semibold mb-4">Quick Links</h4>
          <ul className="space-y-2.5">
            <li><a href="#home" className="hover:text-background transition-colors">Home</a></li>
            <li><a href="#services" className="hover:text-background transition-colors">Services</a></li>
            <li><a href="#printers" className="hover:text-background transition-colors">Printers</a></li>
            <li><a href="#contact" className="hover:text-background transition-colors">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-background font-semibold mb-4">Contact</h4>
          <ul className="space-y-3">
            <li className="flex items-center gap-2"><Mail className="w-4 h-4 text-accent" /> support@printerpro.com</li>
            <li className="flex items-center gap-2"><Phone className="w-4 h-4 text-accent" /> +91 98765 43210</li>
            <li className="flex items-start gap-2"><MapPin className="w-4 h-4 text-accent mt-0.5" /> 123 Tech Park, Bangalore, India</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-background/10 mt-12 pt-8 text-center text-background/40 text-xs">
        © {new Date().getFullYear()} PrinterPro. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
