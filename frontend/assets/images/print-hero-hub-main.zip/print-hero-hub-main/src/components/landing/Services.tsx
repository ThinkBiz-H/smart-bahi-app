import { Wrench, Settings, Shield, Wifi, Package, AlertTriangle } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const services = [
  { icon: Settings, title: "Printer Installation", desc: "Expert setup for inkjet, laser, and multifunction printers in home or office." },
  { icon: Wrench, title: "Printer Repair", desc: "Fast diagnostics and repair for paper jams, print quality issues, and hardware faults." },
  { icon: Shield, title: "AMC Maintenance", desc: "Annual maintenance contracts to keep your printers running at peak performance." },
  { icon: Wifi, title: "Network Setup", desc: "Wireless and wired network printer configuration for seamless multi-device printing." },
  { icon: Package, title: "Cartridge Support", desc: "Genuine and compatible cartridge supply, replacement, and refill services." },
  { icon: AlertTriangle, title: "Troubleshooting", desc: "Remote and on-site troubleshooting for driver errors, connectivity, and print failures." },
];

const Services = () => (
  <section id="services" className="py-24 bg-background">
    <div className="container mx-auto px-4">
      <ScrollReveal className="text-center mb-16">
        <span className="text-sm font-semibold tracking-wider uppercase text-accent">What We Do</span>
        <h2 className="text-3xl sm:text-4xl font-bold mt-3 tracking-tight text-balance">Our Services</h2>
        <p className="text-muted-foreground mt-4 max-w-lg mx-auto" style={{ textWrap: "pretty" }}>
          Comprehensive printer solutions from installation to ongoing maintenance.
        </p>
      </ScrollReveal>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s, i) => (
          <ScrollReveal key={s.title} delay={i * 80}>
            <div className="bg-card rounded-xl p-7 shadow-sm shadow-primary/5 card-hover border border-border/60 h-full">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-5">
                <s.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default Services;
