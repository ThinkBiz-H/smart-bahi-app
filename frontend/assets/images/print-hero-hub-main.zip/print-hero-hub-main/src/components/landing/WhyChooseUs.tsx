import { Zap, UserCheck, DollarSign, MapPin } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const items = [
  { icon: Zap, title: "Fast Service", desc: "Quick turnaround with same-day service for urgent repairs." },
  { icon: UserCheck, title: "Expert Technicians", desc: "Certified professionals with years of printer service experience." },
  { icon: DollarSign, title: "Affordable Pricing", desc: "Transparent, competitive pricing with no hidden costs." },
  { icon: MapPin, title: "On-site Support", desc: "We come to your home or office — no need to carry your printer anywhere." },
];

const WhyChooseUs = () => (
  <section className="py-24 bg-background">
    <div className="container mx-auto px-4">
      <ScrollReveal className="text-center mb-16">
        <span className="text-sm font-semibold tracking-wider uppercase text-accent">Why Us</span>
        <h2 className="text-3xl sm:text-4xl font-bold mt-3 tracking-tight text-balance">Why Choose PrinterPro</h2>
      </ScrollReveal>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {items.map((item, i) => (
          <ScrollReveal key={item.title} delay={i * 100} className="text-center">
            <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-5">
              <item.icon className="w-8 h-8 text-accent" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
          </ScrollReveal>
        ))}
      </div>
    </div>
  </section>
);

export default WhyChooseUs;
